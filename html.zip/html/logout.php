<?php
session_start();
header('Access-Control-Allow-Origin:*');
?>
<html>
<head>
  <title>PINGNETBOX</title>
  <meta charset="utf-8" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./signinstyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.min.css'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,700,300'>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
</head>

<?php
	session_unset();
	session_destroy();
	header("Location: https://www.pingnetbox.com"); 
?>
