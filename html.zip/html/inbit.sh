ifstat -i eth0 -q 1 1 | grep [\\.\d]  | awk '{inbit=($1 * 8 /500000.0 * 100.0)} END {print inbit}'
