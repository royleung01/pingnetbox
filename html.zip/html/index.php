<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
	$username = $_SESSION['username'];	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>PINGNETBOX</title>
  <meta charset="utf-8" content="width=device-width, initial-scale=1.0">
  <meta name="keywords" content="PINGNETBOX, pingnetbox, Traceroute, Trace route, BGP,  AS Number, DNS,whois, PING, ICMP, domain, domain name, Internet, IP, subnet">
  <link rel="stylesheet" href="./style.css">

</head>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript">

var $checkwidth = 0;
var options,options2,options3;
var chart,chart2,chart3;
var input_data;
var data,data2;
var cpu = 0;
var memory = 0;
var inbit = 0;
var outbit = 0;
var pingprocess = 0;
var checkwidth = 0;

$(document).ready(function(){
	
    $('a[href^="#"]').bind('click.smoothscroll',function (e) {
        e.preventDefault();
      
        var target = this.hash,
        $target = $(target);
      
        $('html, body').stop().animate({
            'scrollTop': $target.offset().top
        }, 900, 'swing', function () {
            window.location.hash = target;
        });
    });


	getTracerouteData();	





	$(window).resize(function(){
	var width = window.innerWidth;
       	if(width >=1201)
	{ 
		document.getElementById("topmenu").style.display = "block";
		document.getElementById("topmenu2").style.display = "block";
		checkwidth = 0;

		options = {
                  width: 600, height: 200,
                  redFrom: 90, redTo: 100,
                  yellowFrom:75, yellowTo: 90,
                  minorTicks: 5
                };

                chart.draw(data, options);

		options2 = {
		  title: 'Ping to google DNS',
		  width:900 , height: 300,
		  hAxis: {title: 'Date time'},
		  vAxis: {title: 'Latency'},
		  legend: 'none'
		};

		chart2.draw(data2,options2);


	}

	if((width >=1001) && (width <1201) && (checkwidth == 0))
	{
		checkwidth = 1;
                document.getElementById("topmenu").style.display = "none";
		document.getElementById("topmenu2").style.display = "none";

                options = {
                  width: 400, height: 200,
                  redFrom: 90, redTo: 100,
                  yellowFrom:75, yellowTo: 90,
                  minorTicks: 5
                };

                chart.draw(data, options);

                options2 = {
                  title: 'Ping to google DNS',
                  width:600 , height: 200,
                  hAxis: {title: 'Date time'},
                  vAxis: {title: 'Latency'},
                  legend: 'none'
                };

		chart2.draw(data2,options2);	


	}


	if((width < 1001) && (checkwidth == 0))
	{
		checkwidth = 1;
		document.getElementById("topmenu").style.display = "none";
		document.getElementById("topmenu2").style.display = "none";

		options = {
	          width: 400, height: 200,
       		  redFrom: 90, redTo: 100,
	          yellowFrom:75, yellowTo: 90,
       		  minorTicks: 5
        	};

        	chart.draw(data, options);

		options2 = {
                  title: 'Ping to google DNS',
                  width:300 , height: 100,
                  hAxis: {title: 'Date time'},
                  vAxis: {title: 'Latency'},
                  legend: 'none'
                };

                chart2.draw(data2,options2);


	}

	});


});




function menufunction() {
  var x = document.getElementById("topmenu");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}

function menufunction2() {
  var x = document.getElementById("topmenu2");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}



<!-- Google Chart -->

google.charts.load('current', {'packages':['gauge']});
google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        data = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
          ['Memory', memory],
          ['CPU', cpu],
          ['Network in (Bits)', inbit],
	  ['Network out (Bits)', outbit]
        ]);

        options = {
          width: 600, height: 300,
          redFrom: 90, redTo: 100,
          yellowFrom:75, yellowTo: 90,
          minorTicks: 5 
        };

        chart = new google.visualization.Gauge(document.getElementById('chart_div'));

        chart.draw(data, options);

	$.getJSON('https://www.pingnetbox.com/stat.php', function(data) {

                $.each(data, function(i, field){
                        if(i == "CPU")
                        {
                                cpu = field;
                        }
                        if(i == "Memory")
                        {
                                memory=field;
                        }
                        if(i == "inbit")
                        {
                                inbit=field;
                        }
                        if(i == "outbit")
                        {
                                outbit=field;
                        }

                });

        });


	setInterval(function() {
	$.getJSON('https://www.pingnetbox.com/stat.php', function(data) {

		$.each(data, function(i, field){
			if(i == "CPU")
			{	
				cpu = field;
			}
			if(i == "Memory")
			{
				memory=field;
			}	
			if(i == "inbit")
			{
				inbit=field;
			}
			if(i == "outbit")
			{		
				outbit=field;
			}
			
	      	});
  
	});


	}, 5000);

        setInterval(function() {
          data.setValue(0, 1, memory);
          chart.draw(data, options);
        }, 10000);
        setInterval(function() {
          data.setValue(1, 1, cpu);
          chart.draw(data, options);
        }, 10000);
        setInterval(function() {
          data.setValue(2, 1, inbit);
          chart.draw(data, options);
        }, 10000);
	setInterval(function() {
          data.setValue(3, 1, outbit);
          chart.draw(data, options);
        }, 10000);
      }

<!-- Google Chart -->


<!-- ping Chart -->

google.charts.load('current',{packages:['corechart']});
google.charts.setOnLoadCallback(drawChart2);


function drawChart2() {
// Set Data
chart2 = new google.visualization.LineChart(document.getElementById('pingChart'));

input_data = [['Datetime','Latency'],[0,0]];

data2 = google.visualization.arrayToDataTable(input_data);

// Set Options
options2 = {
  title: 'Ping to google DNS',
  width:900 , height: 300,
  hAxis: {title: 'Date time'},
  vAxis: {title: 'Latency'},
  legend: 'none'
};

	//var temp_array = ['Datetime', 'Latency'];
        input_data = [];
        //input_data.push(temp_array);
        $.getJSON('https://www.pingnetbox.com/script/ping_json.php', function(dataresult) {
                $.each(dataresult, function (key, value) {
                     //console.log(value.Datetime+" "+value.Latency);
                     temp_array = [value.Datetime,parseFloat(value.Latency)];
                     //console.log(temp_array[0]+" "+temp_array[1]);
                     input_data.push(temp_array);
                     //console.log(input_data[0][0]);
                });
        });



 	setInterval(function() {
	//var temp_array = ['Datetime', 'Latency'];
	input_data = [];
	//input_data.push(temp_array);
        $.getJSON('https://www.pingnetbox.com/script/ping_json.php', function(dataresult) {
		$.each(dataresult, function (key, value) {
                     //console.log(value.Datetime+" "+value.Latency);
	             temp_array = [value.Datetime,parseFloat(value.Latency)];
		     //console.log(temp_array[0]+" "+temp_array[1]); 
		     input_data.push(temp_array);
		     //console.log(input_data[0][0]);
		});
        });

        }, 15000);


	setInterval(function() {
	//data2 = google.visualization.arrayToDataTable(input_data);
          data2 = new google.visualization.DataTable();
          data2.addColumn('string','Date Time');
          data2.addColumn('number','Latency');
          data2.addRows(input_data);
          chart2 = new google.visualization.LineChart(document.getElementById('pingChart'));
          chart2.draw(data2, options2);

	}, 5000);



// Draw
chart2 = new google.visualization.LineChart(document.getElementById('pingChart'));
chart2.draw(data2, options2);

}



<!-- ping Chart -->

function getTracerouteData()
{
	setInterval(function() {

	var temp_time;
	var temp_destination;
	var path;
	var printresult ="";

	$.getJSON('https://www.pingnetbox.com/script/traceroute_json.php', function(tracerouteresult) {
                $.each(tracerouteresult, function (key, value) {
                     //console.log(value.Datetime+" "+value.Latency);
                     temp_time = value.Datetime;
		     temp_destination = value.Destination;
                     path = value.Path; 

		     printresult += "<br>=======================<br>Time:"+temp_time+"<br>Destination:"+temp_destination+"<br>Path:<br>";
		     //console.log(printresult);
               
			for (let i = 0; i < path.length; i++) {
				printresult += path[i]['node']+" "+path[i]['AS']+" "+path[i]['Latency']+"ms<br>";
  				//console.log(printresult);
			}
 
		 document.getElementById("traceroute_path").innerHTML = printresult+"=======================<br>";

		});
        });

	//console.log(printresult+"settext");
	 }, 5000);

}


<!-- Ping Process Chart -->

google.charts.load('current', {'packages':['gauge']});
google.charts.setOnLoadCallback(pingProcessChart);

      function pingProcessChart() {

        var data3 = google.visualization.arrayToDataTable([
          ['Label', 'Value'],
	  ['Ping Process', pingprocess]
        ]);

        options3 = {
          width: 600, height: 300,
          redFrom: 90, redTo: 100,
          yellowFrom:75, yellowTo: 90,
          minorTicks: 5
        };

        chart3 = new google.visualization.Gauge(document.getElementById('pingProcessChart'));

        chart3.draw(data3, options3);


        setInterval(function() {
               getDataFromApi("https://www.pingnetbox.com/script/getPingProcess.php");
		//console.log("PingProcess "+pingprocess);
        }, 5000);

        setInterval(function() {
          data3.setValue(0, 1, pingprocess);
          chart3.draw(data3, options3);
        }, 10000);
        
      }



async function getDataFromApi(URL) {
const response = await fetch(URL);
pingprocess = await response.json();
//console.log(data);
}
<!-- Ping Process Chart -->


function formsent()
{
	var name = document.getElementById("name").value;
	var email = document.getElementById("email").value;
	var company = document.getElementById("company").value;
	var subject = document.getElementById("subject").value;
	var msg = document.getElementById("msg").value;

	if((name != "") && (subject != "") && (msg != "") && (company != "") && (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
	{
		var http = new XMLHttpRequest();
		var url = "https://www.pingnetbox.com/getMessage.php";
		var params = "name='"+name+"'&subject='"+subject+"'&msg='"+msg+"'&company='"+company+"'&email='"+email+"'";
		http.open('POST', url, true);

		http.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		
		http.onreadystatechange = function() {
		    if(http.readyState == 4 && http.status == 200) {
		        //alert(http.responseText);
		    }
		}
		http.send(params);		

		alert("Form Sent! Thanks for your enquiry! We will get back to you soon!");
	}
	else
	{
		alert("Please recheck the input information");
	}

}




</script>


<body>


<div class="sticky">
    <ul class="menu">
	<li>
	<a href="#Intro"><img src=./logo.png /></a>
	</li>
	<div id="topmenu">	
	<li>
      <a href="#Intro">Intro</a>
	</li>
	<li >
      <a href="#Usage">Usage</a>
	</li>
	<li >
      <a href="#Report">Report</a>
	</li>
	<li >
      <a href="#About">About</a>
	</li>

	<li >
<?php
	if($username == "")
	{
?>
      <a href="#Intro"><button class="button" id="button" onclick="location.href='./signin.php'">Sign In</button></a>
<?php
	}
	else
	{
?>
	<div class="dropdown">
		<button class="button" id="button" onclick="location.href='./logout.php'">Logout: <?php echo $username ?></button>
		<div class="dropdown-content">
		    <a href="./ping.php">PING</a>
		    <a href="./traceroute.php">TRACEROUTE</a>
		    <a href="./whois.php">WHOIS</a>
		</div>
	</div>
<?php
	}
?>

        </li>

<?php
	if($username == "")
	{
?>
	<li >
      <a href="#Intro"><button class="button1" id="button1" onclick="location.href='./signup.php'">Join Us?</button></a> 
	</li>
<?php
	}
?>
	</div>
	<li>
	<a href="javascript:void(0);" class="icon" onclick="menufunction()">
	</li>
	<li>
	<hr width=100%>
	</li>
   </ul>


    <ul class="menu2">
        <li>
        <a href="#Intro"><img src=./logo.png /></a>
        </li>
        <div id="topmenu2">
        <li>
      <a href="#Intro">Intro</a>
        </li>
        <li >
      <a href="#Usage">Usage</a>
        </li>
        <li >
      <a href="#Report">Report</a>
        </li>
        <li >
      <a href="#About">About</a>
        </li>



<?php
        if($username == "")
        {
?>
	<li>
	      <a href="./signin.php">Sign In</button></a>
	</li>
<?php
        }
        else
        {
?>
	 <li>
      <a href="./ping.php">PING</a>
        </li>

         <li>
      <a href="./traceroute.php">TRACEROUTE</a>
        </li>

         <li>
      <a href="./whois.php">WHOIS</a>
        </li>

         <li>
      <a href="./logout.php">Logout: <?php echo $username ?></a>
        </li>
	

<?php
        }
        if($username == "")
        {
?>
        <li >
      <a href="./signup.php">Join Us?</button></a>
        </li>
<?php
        }
?>


	</div>
	<li>
        <a href="javascript:void(0);" class="icon" onclick="menufunction2()">
        </li>
        <li>
        <hr width=100%>
        </li>
   </ul>



</div>


<a class="anchor" id="Intro"></a>
<div class="intext">
	<h1>What is PINGNETBOX?</h1>	
	<ul>
	<li>	
	We design to build up a websystem which is operated under Raspberry PI for network testing. The testing function includes ping, traceroute, nslookup, whois etc. Those applications will be similar with public looking glass system.   In addition, the user registration function provided for public user to perform their own testing, they can perform the routine ping, traceroute test. Those result stored in the system and user can plot out the result change in time manner with chart.  
	</li>
	<li>
	<img src="raspberrypi.jpg" />
	</li>
	</ul>
	
</div>

<a class="anchor" id="Usage"></a>
<div class="intext2">
	<h1>Current System Usage</h1>
	<div id="chart_div"></div>
</div>

<a class="anchor" id="Report"></a>
<div class="intext3">
        <h1>Latest Test Report</h1>
	<h2>Ping Google DNS (Update every 15Seconds)</h2> 
	<table class="pingChart"><tr><td>
	<div id="pingChart"></div>
	</td></tr></table>	
	<br>
	<h2>Traceroute</h2>
	<span id="traceroute_path">
                Traceroute
        </span>

	<br>
        <h2>Number of Ping Process Running</h2>
	<div id="pingProcessChart"></div>

</div>


<a class="anchor" id="About"></a>
<div class="abouttext">
        <h1>About Us</h1>
	<div id="contact">
		<div id="contact-left">
			<p>Please contact us at <br><br><a href="mailto:info@pingnetbox.com">info@pingnetbox.com</a></p>
		</div>

		<div id="contact-right">
			<fieldset name="form1" id="form1">
			<div id="contact-info">
				<p>	
					Name <br><input type="text" name="name" id="name" value="" size="40">
				</p>
				<p>
					Email <br><input type="email" name="email" id="email" value="" size="40">
				</p>
				<p>
					Company <br><input type="text" name="company" id="company" value="" size="40">
				</p>
			</div>

			<div id="contact-msg">
				<p>
					Subject<br> <input type="text" name="subject" id="subject" value="" size="40">
				</p>
				<p>
					Message<br>
					<textarea id="msg" name="msg" rows="4" cols="40"></textarea></span><br>
				</p>
				<p>
					<input id="submit_btn" type="submit" value="Send" onclick="formsent()">
				</p>
		
			</div>	
			</fieldset>
		</div>
	</div>
</div>

<div class="footer">
	<br>	
	Copyright © 2022 PINGNETBOX.  All Right Reserved.
	<br>
</div>


</body>
</html>
	
