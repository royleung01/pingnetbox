free | grep Mem | awk '{usage=($3/$2 * 100.0)} END {print usage}'
