<?php
header('Access-Control-Allow-Origin:*');
?>
{
"CPU": "0.157721",
"Memory": "4.8495",
"inbit": "0.000192",
"outbit": "0"
}