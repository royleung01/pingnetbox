<?php
header('Access-Control-Allow-Origin:*');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

?>
<html>
<head>
  <title>PINGNETBOX</title>
  <meta charset="utf-8" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./signupstyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.min.css'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,700,300'>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
</head>

<script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }


function formsent()
{
        var username = document.getElementById("username").value;
        var email = document.getElementById("email").value;
        var password = document.getElementById("password").value;
        var passwordRepeat = document.getElementById("passwordRepeat").value;
	var checking = 0;
	var message = "";

	if(password != passwordRepeat)
	{
		checking = 1;
		message += "Password is not the Same\n";
		document.getElementById('passwordLabel').style.color = "RED";
		document.getElementById('passwordRepeatLabel').style.color = "RED";
	}

	var regExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,10}$/;	

	if((password.length < 8) || (password.length > 10))
	{
		checking = 1;
		message += "Password should be between 8 to 10 characters\n";	
		document.getElementById('passwordLabel').style.color = "RED";
                document.getElementById('passwordRepeatLabel').style.color = "RED";
	}

	if(!regExpression.test(password))
	{
		checking = 1;
		message += "Password should be contain at least one number and one special character\n";
		document.getElementById('passwordLabel').style.color = "RED";
                document.getElementById('passwordRepeatLabel').style.color = "RED";
	}	

	if(!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
	{
		checking = 1;
		message += "Please check your email address\n";
		document.getElementById('emailLabel').style.color = "RED";
	}
	else
	{
		document.getElementById('emailLabel').style.color = "Black";	
	}


        if(checking == 0)
        {
		document.getElementById("submitForm").submit();
	}	
	else
	{
		alert(message);
	}

}



</script>

<body translate="no" >


<?php
	$username = "";
	$email = "";
	$password = "";
	$submithidden = "2";
	$message = "";
	$hash_password = "";
	$random_number = rand();
	$authentication = password_hash($random_number,PASSWORD_DEFAULT); 	

	if(isset($_POST['username']))
	{	
		$username=$_POST['username'];
	}
	if(isset($_POST['email']))
	{
        	$email=$_POST['email'];
	}
	if(isset($_POST['password']))
	{
        	$password=$_POST['password'];
	}
	if(isset($_POST['submithidden']))
	{
        	$submithidden=$_POST['submithidden'];
	}

	if($submithidden == "1")
        {

	$servername = "localhost";
	$dbusername = "pingnetbox";
	$dbpassword = "pingnetbox";
	$db = "pingnetbox";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $db);

	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
		//echo $conn->connect_error;
	}

	$sql = "SELECT username FROM user where username = '".$username."'";
	$result = $conn->query($sql);
	
	//print $result->num_rows."<br>";


	$hash_password = password_hash($password,PASSWORD_DEFAULT); 

	//echo $hash_password;

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    //echo "username: " . $row["username"]. "<br>";
		$message = "Username Exist";
	  }
	}
	else
	{
		$sql = "INSERT INTO user (username, password, email, authentication) VALUES ('".$username."', '".$hash_password."', '".$email."','".$authentication."')";

		if ($conn->query($sql) === TRUE) {
		  //echo "New user created, please check email for authentication";
		  $message = "New user created, please check email for authentication";

			//==========================

			$mail = new PHPMailer(true);                              // Passing `true` enables exceptions
			try {
			    //Server settings
			    //$mail->SMTPDebug = 2;                                 // Enable verbose debug output
			    $mail->isSMTP();                                      // Set mailer to use SMTP
			    $mail->Host = 'smtp.zoho.com';                  // Specify main and backup SMTP servers
			    $mail->SMTPAuth = true;                               // Enable SMTP authentication
			    $mail->Username = 'no-reply@pingnetbox.com';             // SMTP username
			    $mail->Password = 'Pingnetbox623^@#';                           // SMTP password
			    $mail->SMTPSecure = 'ssl';                            // Enable SSL encryption, TLS also accepted with port 465
			    $mail->Port = 465;                                    // TCP port to connect to

			    //Recipients
			    $mail->setFrom('no-reply@pingnetbox.com', 'PINGNETBOX User Registation');          //This is the email your form sends From
			    $mail->addAddress($email, $username); // Add a recipient address

			    //Content
			    $mail->isHTML(true);                                  // Set email format to HTML
			    $mail->Subject = 'Pingnetbox Account created - Authenication email ';
			    $mail->Body    = '<html><body><img src="https://www.pingnetbox.com/logo.png" /><br><br><br>Please click the following link for the Account Authenication.<br><a href="https://www.pingnetbox.com/authentication.php?username='.$username.'&authentication='.$authentication.'">'.$authentication.'</a><br></body></html>';
			    //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			    $mail->send();
			    //echo 'Message has been sent';
			} catch (Exception $e) {
			    //echo 'Message could not be sent.';
			    //echo 'Mailer Error: ' . $mail->ErrorInfo;
				
			}





			//==========================




		} else {
		  echo "Username exist, please choose another one";
		}

	} 
	$conn->close();


	
        #print $username." ".$email." ".$password."<br>";
        }
?>


<div class="signup__container">

  <div class="container__child signup__thumbnail">
    <div class="thumbnail__content text-center">
      <a href="./"><img src=logo.png /></a><br><br><br> 
      <h1 class="heading--primary">Welcome to PINGNETBOX</h1><br>
      <h2 class="heading--secondary">Register a new account?</h2><br>
    </div>
  </div>

  <div class="container__child signup__form">
    <form method="post" id="submitForm" action="./signup.php">
      <div class="form-group">
        <label for="username" >Username</label>
        <input class="form-control" type="text" name="username" id="username" />
      </div>
      <div class="form-group">
        <label for="email" id="emailLabel">Email</label>
        <input class="form-control" type="text" name="email" id="email" />
      </div>
      <div class="form-group">
        <label for="password" id="passwordLabel">Password</label>
        <input class="form-control" type="password" name="password" id="password" />
      </div>
      <div class="form-group">
        <label for="passwordRepeat" id="passwordRepeatLabel">Repeat Password</label>
        <input class="form-control" type="password" name="passwordRepeat" id="passwordRepeat" />
      </div>
      <div class="form-group">
        <input class="form-control" type="hidden" name="submithidden" id="submithidden" value="1" />
      </div>     
      <div>
	<label for="message" id="message" style="color:RED"><?php echo $message; ?></label>
      </div>     

 
      <div class="m-t-lg">
        <ul class="list-inline">
          <li>
            <input class="btn btn--form" type="button" value="Register" onclick="formsent()" />
          </li>
        </ul>
      </div>
    </form>  
  </div>
</div>




</body>
</html>
