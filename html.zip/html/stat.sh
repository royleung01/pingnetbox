echo "<?php"
echo "header('Access-Control-Allow-Origin:*');"
echo "?>"



echo "{"
echo -n "\"CPU\": "\"
grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print usage "\","}'

echo -n "\"Memory\": \""
free | grep Mem | awk '{usage=($3/$2 * 100.0)} END {print usage "\","}'
echo -n "\"inbit\": \""
ifstat -i eth0 -q 1 1 | grep [\\.\d]  | awk '{inbit=($1 * 8 /500000.0 * 100.0)} END {print inbit "\","}'
echo -n "\"outbit\": \""
ifstat -i eth0 -q 1 1 | grep [\\.\d]  | awk '{outbit=($2 * 8 /500000.0 * 100.0)} END {print outbit "\""}'
echo -n "}"
