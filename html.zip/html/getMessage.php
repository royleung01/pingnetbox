<?php
header('Access-Control-Allow-Origin:*');
?>


<?php

	$name = $_POST["name"];
	$email = $_POST["email"];
	$company = $_POST["company"];
	$subject = $_POST["subject"];
	$msg = $_POST["msg"]; 

	$fp = fopen('./data/message.txt', 'a'); 
	fwrite($fp, "\n-----------------\n"); 
	fwrite($fp, date('d-m-y h:i:s')."\n");
	fwrite($fp, $name."\n");  
	fwrite($fp, $email."\n");  
	fwrite($fp, $company."\n");
	fwrite($fp, $subject."\n");
	fwrite($fp, $msg."\n");
	fwrite($fp, "-----------------\n");


	fclose($fp);  
  


?>
