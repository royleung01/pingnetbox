<?php
session_start();
header('Access-Control-Allow-Origin:*');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';
?>
<html>
<head>
  <title>PINGNETBOX</title>
  <meta charset="utf-8" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./signinstyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.min.css'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,700,300'>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
</head>

<script>
  if (document.location.search.match(/type=embed/gi)) {
    window.parent.postMessage("resize", "*");
  }


function formsent()
{
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;
	var checking = 0;
	var message = "";

	if((password == "") || (username == ""))
	{
		checking = 1;
		message += "Please input the correct Login information\n";
		document.getElementById('usernameLabel').style.color = "RED";
		document.getElementById('passwordLabel').style.color = "RED";
	}	
	else
	{
		document.getElementById('usernameLabel').style.color = "Black";
		document.getElementById('passwordLabel').style.color = "Black";
	}


        if(checking == 0)
        {
		document.getElementById("submitForm").submit();
	}	
	else
	{
		alert(message);
	}

}



</script>

<body translate="no" >


<?php
	$username = "";
	$password = "";
	$hash_password = "";
	$submithidden = "2";
	$message = "";

	if(isset($_POST['username']))
	{	
		$username=$_POST['username'];
	}
	if(isset($_POST['password']))
	{
        	$password=$_POST['password'];
	}
	if(isset($_POST['submithidden']))
	{
        	$submithidden=$_POST['submithidden'];
	}

	if($submithidden == "1")
        {

	$servername = "localhost";
	$dbusername = "pingnetbox";
	$dbpassword = "pingnetbox";
	$db = "pingnetbox";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $db);

	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
		//echo $conn->connect_error;
	}

	$sql = "SELECT password,checkaccount FROM user where username = '".$username."'";
	$result = $conn->query($sql);
	
	//print $result->num_rows."<br>";

	//echo $hash_password;

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    //echo "username: " . $row["username"]. "<br>";
		if($row["checkaccount"] == NULL)
		{
			$message = "Please Validate your account by Email first";
		}
		else
		{
			$hash_password = $row["password"];
			if(password_verify($password,$hash_password))
			{
				$message = "Login Success";
				$_SESSION["username"] = $username;
				header("Location: https://www.pingnetbox.com"); 
			}
			else
			{
				$message = "Password Error?";
			}
		}
	  }
	}
	else
	{
		$message = "No this account, Register?";
	} 
	$conn->close();
	
        }
?>


<div class="signup__container">

  <div class="container__child signup__thumbnail">
    <div class="thumbnail__content text-center">
      <a href="./index.html"><img src=logo.png /></a><br><br><br> 
      <h1 class="heading--primary">Welcome to PINGNETBOX</h1><br>
      <a href="./signup.php" class="signup__link"><h2 class="heading--secondary">Register a new account?</h2></a><br>
    </div>
  </div>

  <div class="container__child signup__form">
    <form method="post" id="submitForm" action="./signin.php">
      <div class="form-group">
        <label for="username" id="usernameLabel">Username</label>
        <input class="form-control" type="text" name="username" id="username" size="30" />
      </div>
      <div class="form-group">
        <label for="password" id="passwordLabel">Password</label>
        <input class="form-control" type="password" name="password" id="password" size="30" />
      </div>
      <div class="form-group">
        <input class="form-control" type="hidden" name="submithidden" id="submithidden" value="1" />
      </div>     
      <div>
	<label for="message" id="message" style="color:RED"><?php echo $message; ?></label>
      </div>     
      <div class="m-t-lg">
        <ul class="list-inline">
          <li>
            <input class="btn btn--form" type="button" value="Sign In" onclick="formsent()" />
          </li>
	  <li>
            <input class="btn btn--form" type="button" value="Forget Password?" onclick="location.href='./passwordReset.php'" />
          </li>
        </ul>
      </div>
    </form>  
  </div>
</div>




</body>
</html>
