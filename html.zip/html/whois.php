<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
	$username = $_SESSION['username'];	
}
else
{
	header("Location: https://www.pingnetbox.com");	
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>PINGNETBOX</title>
  <meta charset="utf-8" content="width=device-width, initial-scale=1.0">
  <meta name="keywords" content="PINGNETBOX, Traceroute, Trace route, BGP,  AS Number, DNS,whois, PING, ICMP, domain, domain name, Internet, IP, subnet">
  <link rel="stylesheet" href="./style.css">

</head>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript">

var $checkwidth = 0;
var checkwidth = 0;

$(document).ready(function(){
	
    $('a[href^="#"]').bind('click.smoothscroll',function (e) {
        e.preventDefault();
      
        var target = this.hash,
        $target = $(target);
      
        $('html, body').stop().animate({
            'scrollTop': $target.offset().top
        }, 900, 'swing', function () {
            window.location.hash = target;
        });
    });


	$(window).resize(function(){
	var width = window.innerWidth;
       	if(width >=1001)
	{ 
		document.getElementById("topmenu").style.display = "block";
		document.getElementById("topmenu2").style.display = "block";
		checkwidth = 0;

	}

	if((width < 1001) && (checkwidth == 0))
	{
		checkwidth = 1;
		document.getElementById("topmenu").style.display = "none";
		document.getElementById("topmenu2").style.display = "none";

	}

	});


});




function menufunction() {
  var x = document.getElementById("topmenu");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}

function menufunction2() {
  var x = document.getElementById("topmenu2");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}




function getwhois()
{
	var domain = document.getElementById("whoistext").value;
	var temp_time;
	var temp_domain;
	var result;
	var whoisresult ="";
	var printresult = "";

	$.getJSON('https://www.pingnetbox.com/script/whois_json.php?domain='+domain, function(result) {
                $.each(result, function (key, value) {
                     //console.log(value.Datetime+" "+value.Latency);
                     temp_time = value.Datetime;
		     temp_domain = value.Domain;
                     whoisresult = value.Result; 

		     printresult += "<br>=======================<br>Time:"+temp_time+"<br>Domain:"+temp_domain+"<br>Result:<br>"+whoisresult;
		     //console.log(printresult);
               
		 document.getElementById("whois").innerHTML = printresult+"=======================<br>";

		});
	});

}


</script>


<body>


<div class="sticky">
    <ul class="menu">
	<li>
	<a href="./#Intro"><img src=./logo.png /></a>
	</li>
	<div id="topmenu">	
	<li>
      <a href="./#Intro">Intro</a>
	</li>
	<li >
      <a href="./#Usage">Usage</a>
	</li>
	<li >
      <a href="./#Report">Report</a>
	</li>
	<li >
      <a href="./#About">About</a>
	</li>
	<li >
<?php
	if($username == "")
	{
?>
      <a href="#Intro"><button class="button" id="button" onclick="location.href='./signin.php'">Sign In</button></a>
<?php
	}
	else
	{
?>
	<div class="dropdown">
		<button class="button" id="button" onclick="location.href='./logout.php'">Logout: <?php echo $username ?></button>
		<div class="dropdown-content">
		    <a href="./ping.php">PING</a>
		    <a href="./traceroute.php">TRACEROUTE</a>
		    <a href="./whois.php">WHOIS</a>
		</div>
	</div>
<?php
	}
?>

        </li>

<?php
	if($username == "")
	{
?>
	<li >
      <a href="#Intro"><button class="button1" id="button1" onclick="location.href='./signup.php'">Join Us?</button></a> 
	</li>
<?php
	}
?>
	</div>
	<li>
	<a href="javascript:void(0);" class="icon" onclick="menufunction()">
	</li>
	<li>
	<hr width=100%>
	</li>
   </ul>

    <ul class="menu2">
        <li>
        <a href="#Intro"><img src=./logo.png /></a>
        </li>
        <div id="topmenu2">
        <li>
      <a href="#Intro">Intro</a>
        </li>
        <li >
      <a href="#Usage">Usage</a>
        </li>
        <li >
      <a href="#Report">Report</a>
        </li>
        <li >
      <a href="#About">About</a>
        </li>

<?php
        if($username == "")
        {
?>
        <li>
              <a href="./signin.php">Sign In</button></a>
        </li>
<?php
        }
        else
        {
?>
         <li>
      <a href="./ping.php">PING</a>
        </li>

         <li>
      <a href="./traceroute.php">TRACEROUTE</a>
        </li>

         <li>
      <a href="./whois.php">WHOIS</a>
        </li>

         <li>
      <a href="./logout.php">Logout: <?php echo $username ?></a>
        </li>


<?php
        }
        if($username == "")
        {
?>
        <li >
      <a href="./signup.php">Join Us?</button></a>
        </li>
<?php
        }
?>



        </div>
        <li>
        <a href="javascript:void(0);" class="icon" onclick="menufunction2()">
        </li>
        <li>
        <hr width=100%>
        </li>
   </ul>


</div>


<a class="anchor" id="Report"></a>
<div class="intext3">
        <h1>WHOIS</h1>
	<h2>Please input domain name</h2> 
	<input type=text id="whoistext" size=50 /> <button id=submit onclick="getwhois()">whois</button>	
	<br><br>
	<span id="whois">
	</span>
</div>


<div class="footer">
	<br>	
	Copyright © 2022 PINGNETBOX.  All Right Reserved.
	<br>
</div>


</body>
</html>
	
