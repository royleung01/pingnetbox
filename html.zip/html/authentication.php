<?php
header('Access-Control-Allow-Origin:*');
?>
<html>
<head>
  <title>PINGNETBOX</title>
  <meta charset="utf-8" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./signupstyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.min.css'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300'>
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto:400,700,300'>
  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
</head>

<html>
<body translate="no" >

<?php
	$username = "";
	$authentication = "";

	if(isset($_GET['username']))
	{	
		$username=$_GET['username'];
	}
	if(isset($_GET['authentication']))
	{
        	$authentication=$_GET['authentication'];
	}

	if($username != "")
	{
	$servername = "localhost";
	$dbusername = "pingnetbox";
	$dbpassword = "pingnetbox";
	$db = "pingnetbox";

	$conn = new mysqli($servername, $dbusername, $dbpassword, $db);

	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
		//echo $conn->connect_error;
	}

	$sql = "SELECT username FROM user where username = '".$username."' and authentication= '".$authentication."' and checkaccount IS NULL";
	$result = $conn->query($sql);

	//echo $sql."<br>";
	
	//print $result->num_rows."<br>";

	if ($result->num_rows > 0) {
	  // output data of each row
	  while($row = $result->fetch_assoc()) {
	    //echo "username: " . $row["username"]. "<br>";
		$message = "Username Exist";
		$sql = "update user set checkaccount = '1' where username = '".$username."' and authentication= '".$authentication."'"; 
	
		//echo $sql."<br>";

                if ($conn->query($sql) === TRUE) {
		  echo "Authentication Completed, Please login www.pingnetbox.com";
                } else {
                  echo "Username exist, please choose another one";
                }
	  }
	}
	else
	{
		  echo "Authentication Error, please contact our administrator.";
	} 
	$conn->close();


	
        }
?>

</body>
</html>
