#!/bin/sh

pingcommand=$(sudo traceroute -n -A $1 --icmp -q 1)
ok=$?
result=$(echo -e "$pingcommand" | awk '$3 ~ /\[AS/ {print $2 " " $3 " " $4}')

#date=`date -u '+%Y-%m-%d|%H:%M:%S'`
date=`date -u '+%H:%M:%S'`

result2=$(echo "$result" | sed -z 's/\n/, /g') 

        echo "$date $1|$result2"

