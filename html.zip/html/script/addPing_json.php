<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
        $username = $_SESSION['username'];
}
else
{
        header("Location: https://www.pingnetbox.com");
}
?>
<?php
	$domain = $_GET['domain'];
	print "[\n";
	//print $domain;
	$variable = array('Result' => 'result');

	$command = 'ping '.$domain.' -i 0.2 -c 5 -W 1 | grep rtt | awk \'{print $4}\' | cut -f 2 -d \'/\'';
	#echo $command."\n";

	$result = shell_exec($command);

		if($result != null)
		{	
			$variable = array('Result' => $result);
			echo json_encode( $variable );
		}
		else
		{
			$variable = array('Result' => '0');
                        echo json_encode( $variable );
		}
	

	print "]";

	#echo json_encode( $variable );
?>
