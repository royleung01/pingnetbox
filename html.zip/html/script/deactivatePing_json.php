<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
        $username = $_SESSION['username'];
}
else
{
        header("Location: https://www.pingnetbox.com");
}
?>
<?php
	$domain = $_GET['domain'];
	print "[\n";
	//print $domain;
	$variable = array('Result' => 'result', 'Message' => 'message');
	$limited = 0;

			$servername = "localhost";
		        $dbusername = "pingnetbox";
		        $dbpassword = "pingnetbox";
		        $db = "pingnetbox";
		
		        $conn = new mysqli($servername, $dbusername, $dbpassword, $db);

		        if ($conn->connect_error) {
		          die("Connection failed: " . $conn->connect_error);
		                //echo $conn->connect_error;
		        }

			
			$sql = "update ping set pingenable = 'N' where username = '".$username."' and destination='".$domain."'";

        		if ($conn->query($sql) == TRUE) 
			{
		                $message = "Deactivate the schedule Ping Successful";
 		       	}
		       	else
		       	{
				$message = "Deactivate fail, please check the configuration";
			}

			$variable = array('Result' => $result,'Message' => $message);	
			echo json_encode( $variable );

	print "]";

	#echo json_encode( $variable );
?>
