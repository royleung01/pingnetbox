<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
        $username = $_SESSION['username'];
}
else
{
        header("Location: https://www.pingnetbox.com");
}
?>
<?php
	$domain = $_GET['domain'];
	print "[\n";
	$variable = array('Datetime' => 'Datetime', 'Destination' => 'Destination', 'Path' => 'Path' );
	
	$date = shell_exec('date -u \'+%H:%M:%S\'');
	$date = trim($date, "\n");

	$trace = shell_exec('traceroute -n -A '.$domain.' --icmp -q 1 | awk \'$3 ~ /\\[AS/ {print $2 " " $3 " " $4}\' | sed -z \'s/\n/, /g\'');

	if($trace == "")
	{ 
		$path[0] = array('node' => 'Invalid',
                                                'AS' => 'Invalid',
                                                'Latency' => 'No Result ');


		$variable = array('Datetime' => $date,
                                 'Destination' => $domain." Invalid Domain",
                                 'Path' => $path);

                echo json_encode( $variable );

	}
	else
	{
	$trace = trim($trace,"\n");
	$trace = trim($trace," ");
	$trace = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "", $trace);
	
	//print $trace."----";

	$result = $date." ".$domain."|".$trace;

	//print $result."\n";

	$array_data = explode("\n",$result);

	#07:10:05 8.8.8.8|218.102.40.50 [AS4760] 3.759, 72.14.219.16 [AS15169] 5.631, 142.250.61.129 [AS15169] 4.252, 142.251.245.21 [AS15169] 4.426, 8.8.8.8 [AS15169] 4.344,

	//print $array_data[0]."\n";

	//print count($array_data);
	for($i=0;$i<count($array_data);$i++)
	{
		$first_extract = explode("|",$array_data[$i]); 

		//print $first_extract[0]."\n";
		//print $first_extract[1]."\n";


		$time_destination = explode(" ",$first_extract[0]);
		$traceroute = explode(", ",$first_extract[1]);

		#print $time_destination[0]." ".$time_destination[1]."\n";

		#$path = array('node' => 'node', 'AS' => 'AS' ,'Latency' => 'Latency');

		for($j=0;$j<count($traceroute);$j++)
		{
			if($traceroute[$j] != null)
			{
				#print $traceroute[$j]."\n";
				$pathresult = explode(" ",$traceroute[$j]);
				$path[$j] = array('node' => $pathresult[0],
						'AS' => $pathresult[1],
						'Latency' => $pathresult[2]);	
			}
		}	

		if($time_destination[0] != null)
		{	
		$variable = array('Datetime' => $time_destination[0], 
				 'Destination' => $time_destination[1],
				 'Path' => $path);

		echo json_encode( $variable );

			if(count($array_data) == $i+1)
			{

			}	
			else
			{
				print ",\n";
			}
		}
	}

	}

	print "\n]\n";

	#echo json_encode( $variable );
	
?>
