#!/bin/sh

pingcommand=$(ping $1 -i 0.2 -c 5 -W 1)
ok=$?
avg=$(echo -e "$pingcommand" | grep rtt | awk '{print $4}' | cut -f 2 -d "/")

#date=`date -u '+%Y-%m-%d|%H:%M:%S'`
date=`date -u '+%H:%M:%S'`

if [ $ok -eq 0 ]
then
        echo "$date $avg"
else
        echo "0"
fi
