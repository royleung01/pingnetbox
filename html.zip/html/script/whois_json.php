<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
        $username = $_SESSION['username'];
}
else
{
        header("Location: https://www.pingnetbox.com");
}
?>
<?php
	$domain = $_GET['domain'];
	print "[\n";
	$variable = array('Datetime' => 'Datetime', 'Domain' => 'Domain', 'Result' => 'Result' );

	$result = shell_exec('whois '.$domain);

	//echo "-----".strpos($result,'o match for')."-----";
	//echo "-----".strpos($result,'Incorrect input')."-----";


	//echo $domain;

	$checker = 0;

	if(strpos($result,'o match for') == TRUE) 
	{
		$checker = 1;
	}

	if(strpos($result,'ncorrect input') == TRUE )
	{
		$checker = 1;
	}
	

	while($checker == 1)
	{
		$temp = explode('.',$domain);	
	
		$domain = "";	

		for($i=1;$i<count($temp);$i++)
		{
			if($i < count($temp)-1)
			{	
				$domain .= $temp[$i].".";
			}
			else
			{
				$domain .= $temp[$i];
			}
		}

		//echo "------".$domain."\n";
		$result = shell_exec('whois '.$domain);
		//echo "-----".strpos($result,'o match for')."-----";
		//print $result."\n";	
		//$result = "";
		//exit();
		
		 $checker = 0;

		if(strpos($result,'o match for') == TRUE) 
	        {
	                $checker = 1;
	        }

	        if(strpos($result,'ncorrect input') == TRUE )
	        {
	                $checker = 1;
	        }



	}

	$datetime = shell_exec("date -u '+%H:%M:%S'");

	$result = str_replace("\n","<br>",$result);

		$variable = array('Datetime' => $datetime, 
				 'Domain' => $domain,
				 'Result' => $result);

		echo json_encode( $variable );
	
	

	print "\n]\n";

	#echo json_encode( $variable );
?>
