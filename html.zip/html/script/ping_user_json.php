<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
        $username = $_SESSION['username'];
}
else
{
        header("Location: https://www.pingnetbox.com");
}
?>
<?php
        $domain = $_GET['domain'];
	$filepath = "/var/www/html/result/";

	//print $domain."\n";
	//print $username."\n";

	//$username = "9";
	//$domain = "1.1.1.2";

	$command =  'tail -n 50 '.$filepath."ping_".$username."_".$domain.".txt";

	print "[";

	$variable = array('Datetime' => 'Datetime', 'Latency' => 'Latency');
	$result =  shell_exec($command);

	
	//print $result;


	$array_data = explode("\n",$result);

	#print count($array_data);

	for($i=0;$i<count($array_data)-1;$i++)
	{
		$temp = explode(" ",$array_data[$i]);

		#print $temp[0]." ".$temp[1]."\n";
	
		if($temp[0] != null)
		{	
		$variable = array('Datetime' => $temp[0], 
				 'Latency' => $temp[1]);

		echo json_encode( $variable );
	
			if($array_data[$i+1] == null)
			{

			}	
			else
			{
				print ",\n";
			}
		}
	}

	print "]";

	#echo json_encode( $variable );
?>
