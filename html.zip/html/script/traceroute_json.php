<?php
header('Access-Control-Allow-Origin:*');
?>
<?php
	print "[\n";

	$variable = array('Datetime' => 'Datetime', 'Destination' => 'Destination', 'Path' => 'Path' );

	$array_data = explode("\n",shell_exec('tail -n 1 tracerouteresult.php'));

	#07:10:05 8.8.8.8|218.102.40.50 [AS4760] 3.759, 72.14.219.16 [AS15169] 5.631, 142.250.61.129 [AS15169] 4.252, 142.251.245.21 [AS15169] 4.426, 8.8.8.8 [AS15169] 4.344,

	#print $array_data[0]."\n";

	for($i=0;$i<count($array_data)-1;$i++)
	{
		$first_extract = explode("|",$array_data[$i]); 

		#print $first_extract[0]."\n";
		#print $first_extract[1]."\n";


		$time_destination = explode(" ",$first_extract[0]);
		$traceroute = explode(", ",$first_extract[1]);

		#print $time_destination[0]." ".$time_destination[1]."\n";

		#$path = array('node' => 'node', 'AS' => 'AS' ,'Latency' => 'Latency');

		for($j=0;$j<count($traceroute)-1;$j++)
		{
			if($traceroute[$j] != null)
			{
				#print $traceroute[$j]."\n";
				$pathresult = explode(" ",$traceroute[$j]);
				$path[$j] = array('node' => $pathresult[0],
						'AS' => $pathresult[1],
						'Latency' => $pathresult[2]);	
			}
		}	

		if($time_destination[0] != null)
		{	
		$variable = array('Datetime' => $time_destination[0], 
				 'Destination' => $time_destination[1],
				 'Path' => $path);

		echo json_encode( $variable );
	
			if($array_data[$i+1] == null)
			{

			}	
			else
			{
				print ",\n";
			}
		}
	}

	print "\n]\n";

	#echo json_encode( $variable );
?>
