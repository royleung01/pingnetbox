<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
        $username = $_SESSION['username'];
}
else
{
        header("Location: https://www.pingnetbox.com");
}
?>
<?php
	$domain = $_GET['domain'];
	print "[\n";
	//print $domain;
	$variable = array('Result' => 'result', 'Message' => 'message');
	$limited = 0;

	$command = 'ping '.$domain.' -i 0.2 -c 5 -W 1 | grep rtt | awk \'{print $4}\' | cut -f 2 -d \'/\'';
	#echo $command."\n";

	$result = shell_exec($command);

		if($result != null)
		{	
			$servername = "localhost";
		        $dbusername = "pingnetbox";
		        $dbpassword = "pingnetbox";
		        $db = "pingnetbox";
		
		        $conn = new mysqli($servername, $dbusername, $dbpassword, $db);

		        if ($conn->connect_error) {
		          die("Connection failed: " . $conn->connect_error);
		                //echo $conn->connect_error;
		        }

			
			$sql2 = "SELECT count(destination) as countlimit FROM ping where username = '".$username."' and pingenable ='Y'";
                        $resultSQL2 = $conn->query($sql2);

			while($row2 = $resultSQL2->fetch_assoc()) {
                                $limited = $row2['countlimit'];
                        }


		       	if($limited >= 10)
			{
				$message = "You reach the Scheduled test limited ".$limited;	
				$variable = array('Result' => '0','Message' => $message);
                        	echo json_encode( $variable );
	
			}
		       	else
		       	{
				$sql = "update ping set pingenable = 'Y' where username = '".$username."' and destination='".$domain."'"; 

		                if ($conn->query($sql) === TRUE) {
					  $limited = $limited+1;
			                  $message = "Reactivate Ping Test. ".$limited."/10";
				
					  $variable = array('Result' => $result,'Message' => $message);	
		    			  echo json_encode( $variable );
				}
			}
		}
		else
		{
			$message = "Ping Fail of Domain/IP";
			$variable = array('Result' => '0','Message' => $message);
                        echo json_encode( $variable );
		}
	

	print "]";

	#echo json_encode( $variable );
?>
