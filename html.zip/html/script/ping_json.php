<?php
header('Access-Control-Allow-Origin:*');
?>
<?php
	print "[\n";

	$variable = array('Datetime' => 'Datetime', 'Latency' => 'Latency');

	$array_data = explode("\n",shell_exec('tail -n 50 pingresult.php'));
	#$array_data = explode("\n",file_get_contents('pingresult.php'));

	for($i=count($array_data)-50;$i<count($array_data);$i++)
	{
		$temp = explode(" ",$array_data[$i]);

		#print $temp[0]." ".$temp[1]."\n";
	
		if($temp[0] != null)
		{	
		$variable = array('Datetime' => $temp[0], 
				 'Latency' => $temp[1]);

		echo json_encode( $variable );
	
			if($array_data[$i+1] == null)
			{

			}	
			else
			{
				print ",\n";
			}
		}
	}

	print "]";

	#echo json_encode( $variable );
?>
