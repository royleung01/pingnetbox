<?php
session_start();
header('Access-Control-Allow-Origin:*');
			
			$filepath = "/var/www/html/result/";
			$servername = "localhost";
		        $dbusername = "pingnetbox";
		        $dbpassword = "pingnetbox";
		        $db = "pingnetbox";
		
		        $conn = new mysqli($servername, $dbusername, $dbpassword, $db);

		        if ($conn->connect_error) {
		          die("Connection failed: " . $conn->connect_error);
		                //echo $conn->connect_error;
		        }

			
			$sql = "SELECT username,destination FROM ping where pingenable = 'Y'";
			$resultSQL = $conn->query($sql);

        		if ($resultSQL->num_rows > 0) 
			{
		          	// output data of each row
		          	while($row = $resultSQL->fetch_assoc()) 
				{
		                	$message = "Ping Test Domain already Exist";
				
					$command = 'ping '.$row['destination'].' -i 0.2 -c 5 -W 1 | grep rtt | awk \'{print $4}\' | cut -f 2 -d \'/\'';
					$result = shell_exec($command);
	
			                if($result != null)
	               			{
						$datetime = shell_exec("date -u '+%H:%M:%S'");	
						echo trim($datetime,"\n")." ".$result."\n";
						$fp = fopen($filepath."/ping_".$row['username']."_".$row['destination'].".txt", 'a');//opens file in append mode
						fwrite($fp, trim($datetime,"\n")." ".$result);  
						fclose($fp);  	
					}
					else
	       			        {
	                        		$message = "Ping Fail of Domain/IP";
			                        //$variable = array('Result' => '0','Message' => $message);
			                        //echo json_encode( $variable );
			                }
				}
			}

			//$variable = array('Result' => $result,'Message' => $message);	
			//echo json_encode( $variable );
	

	//echo json_encode( $variable );
?>
