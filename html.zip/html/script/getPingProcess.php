<?php
header('Access-Control-Allow-Origin:*');
?>
<?php

print exec('ps -ef | grep ping | wc -l')-1;

?>
