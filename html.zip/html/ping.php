<?php
session_start();
header('Access-Control-Allow-Origin:*');
$username="";
if($_SESSION["username"] != null)
{
	$username = $_SESSION['username'];	
}
else
{
	header("Location: https://www.pingnetbox.com");	
}

			$limited = 0;
 			$servername = "localhost";
                        $dbusername = "pingnetbox";
                        $dbpassword = "pingnetbox";
                        $db = "pingnetbox";

                        $conn = new mysqli($servername, $dbusername, $dbpassword, $db);

                        if ($conn->connect_error) {
                          die("Connection failed: " . $conn->connect_error);
                                //echo $conn->connect_error;
                        }


                        $sql2 = "SELECT count(destination) as countlimit FROM ping where username = '".$username."' and pingenable = 'Y'";
                        $resultSQL2 = $conn->query($sql2);

                        while($row2 = $resultSQL2->fetch_assoc()) {
                                $limited = $row2['countlimit'];
                        }


			$sql3 = "SELECT destination FROM ping where username = '".$username."' and pingenable = 'Y'";
                        $resultSQL3 = $conn->query($sql3);

			$destination[$limited];

			$counter = 0;

                        while($row3 = $resultSQL3->fetch_assoc()) {
                                $destination[$counter] = $row3['destination'];
				$counter++;
                        }

			//------------- Reactivate

			$sql4 = "SELECT count(destination) as countlimit FROM ping where username = '".$username."' and pingenable = 'N'";
                        $resultSQL4 = $conn->query($sql4);

                        while($row4 = $resultSQL4->fetch_assoc()) {
                                $limited2 = $row4['countlimit'];
                        }


                        $sql5 = "SELECT destination FROM ping where username = '".$username."' and pingenable = 'N'";
                        $resultSQL5 = $conn->query($sql5);

                        $destination2[$limited2];

                        $counter2 = 0;

                        while($row5 = $resultSQL5->fetch_assoc()) {
                                $destination2[$counter2] = $row5['destination'];
                                $counter2++;
                        }
	

			$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>PINGNETBOX</title>
  <meta charset="utf-8" content="width=device-width, initial-scale=1.0">
  <meta name="keywords" content="PINGNETBOX, Traceroute, Trace route, BGP,  AS Number, DNS,whois, PING, ICMP, domain, domain name, Internet, IP, subnet">
  <link rel="stylesheet" href="./style.css">

</head>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="//code.jquery.com/jquery-latest.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript">

var $checkwidth = 0;
var options2 = [];
var chart2 = [];
var input_data = [];
var data2 = [];

var options3 = [];
var chart3 = [];
var input_data2 = [];
var data3 = [];

var cpu = 0;
var memory = 0;
var inbit = 0;
var outbit = 0;
var pingprocess = 0;
var checkwidth = 0;

$(document).ready(function(){
	
    $('a[href^="#"]').bind('click.smoothscroll',function (e) {
        e.preventDefault();
      
        var target = this.hash,
        $target = $(target);
      
        $('html, body').stop().animate({
            'scrollTop': $target.offset().top
        }, 900, 'swing', function () {
            window.location.hash = target;
        });
    });



	$(window).resize(function(){
	var width = window.innerWidth;
       	if(width >=1001)
	{ 
		document.getElementById("topmenu").style.display = "block";
		document.getElementById("topmenu2").style.display = "block";

		checkwidth = 0;

		<?php
		for($i=0;$i<$limited;$i++)
		{
		?>

		options2[<?php print $i;?>] = {
		  title: 'Ping to <?php print $destination[$i];?>',
		  width:900 , height: 300,
		  hAxis: {title: 'Date time'},
		  vAxis: {title: 'Latency'},
		  legend: 'none'
		};

		chart2[<?php print $i;?>].draw(data2[<?php print $i;?>],options2[<?php print $i;?>]);

		<?php
		}
		?>

		
		<?php
                for($i=0;$i<$limited2;$i++)
                {
                ?>

                options3[<?php print $i;?>] = {
                  title: 'Ping to <?php print $destination2[$i];?>',
                  width:900 , height: 300,
                  hAxis: {title: 'Date time'},
                  vAxis: {title: 'Latency'},
                  legend: 'none'
                };

                chart3[<?php print $i;?>].draw(data3[<?php print $i;?>],options3[<?php print $i;?>]);

                <?php
                }
                ?>




	}

	if((width < 1001) && (checkwidth == 0))
	{
		checkwidth = 1;
		document.getElementById("topmenu").style.display = "none";
		document.getElementById("topmenu2").style.display = "none";


		<?php
                for($i=0;$i<$limited;$i++)
                {
                ?>

		options2[<?php print $i;?>] = {
                  title: 'Ping to <?php print $destination[$i];?>',
                  width:300 , height: 100,
                  hAxis: {title: 'Date time'},
                  vAxis: {title: 'Latency'},
                  legend: 'none'
                };

                chart2[<?php print $i;?>].draw(data2[<?php print $i;?>],options2[<?php print $i;?>]);

		<?php
                }
                ?>

		<?php
                for($i=0;$i<$limited2;$i++)
                {
                ?>

                options3[<?php print $i;?>] = {
                  title: 'Ping to <?php print $destination2[$i];?>',
                  width:300 , height: 100,
                  hAxis: {title: 'Date time'},
                  vAxis: {title: 'Latency'},
                  legend: 'none'
                };

                chart3[<?php print $i;?>].draw(data3[<?php print $i;?>],options3[<?php print $i;?>]);

                <?php
                }
                ?>



	}

	});


});




function menufunction() {
  var x = document.getElementById("topmenu");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}


function menufunction2() {
  var x = document.getElementById("topmenu2");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}



<!-- ping Chart -->

<?php
  for($i=0;$i<$limited;$i++)
  {
?>

google.charts.load('current',{packages:['corechart']});
google.charts.setOnLoadCallback(drawChart2<?php print $i;?>);

function drawChart2<?php print $i;?>() {
// Set Data
chart2[<?php print $i;?>] = new google.visualization.LineChart(document.getElementById('pingChart<?php print $i;?>'));

input_data[<?php print $i;?>] = [['Datetime','Latency'],[0,0]];

data2[<?php print $i;?>] = google.visualization.arrayToDataTable(input_data[<?php print $i;?>]);

// Set Options
options2[<?php print $i;?>] = {
  title: 'Ping to <?php print $destination[$i];?>',
  width:900 , height: 300,
  hAxis: {title: 'Date time'},
  vAxis: {title: 'Latency'},
  legend: 'none'
};

	input_data[<?php print $i;?>] = [];
        //input_data.push(temp_array);
        $.getJSON('https://www.pingnetbox.com/script/ping_user_json.php?domain=<?php print $destination[$i];?>', function(dataresult<?php print $i;?>) {
                $.each(dataresult<?php print $i;?>, function (key<?php print $i;?>, value<?php print $i;?>) {
                     //console.log(value<?php print $i;?>.Datetime+" "+value<?php print $i;?>.Latency);
                     temp_array<?php print $i;?> = [value<?php print $i;?>.Datetime,parseFloat(value<?php print $i;?>.Latency)];
                     //console.log(temp_array<?php print $i;?>[0]+" "+temp_array<?php print $i;?>[1]);
                     input_data[<?php print $i;?>].push(temp_array<?php print $i;?>);
                     //console.log(input_data[0][0]);
                });
        });


 	setInterval(function() {
	//var temp_array = ['Datetime', 'Latency'];
	input_data[<?php print $i;?>] = [];
	//input_data.push(temp_array);
        $.getJSON('https://www.pingnetbox.com/script/ping_user_json.php?domain=<?php print $destination[$i];?>', function(dataresult<?php print $i;?>) {
		$.each(dataresult<?php print $i;?>, function (key<?php print $i;?>, value<?php print $i;?>) {
                     //console.log(value<?php print $i;?>.Datetime+" "+value<?php print $i;?>.Latency);
	             temp_array<?php print $i;?> = [value<?php print $i;?>.Datetime,parseFloat(value<?php print $i;?>.Latency)];
		     //console.log(temp_array<?php print $i;?>[0]+" "+temp_array<?php print $i;?>[1]); 
		     input_data[<?php print $i;?>].push(temp_array<?php print $i;?>);
		     //console.log(input_data[0][0]);
		});
        });

        }, 250000);


	setInterval(function() {
	//data2 = google.visualization.arrayToDataTable(input_data);
          data2[<?php print $i;?>] = new google.visualization.DataTable();
          data2[<?php print $i;?>].addColumn('string','Date Time');
          data2[<?php print $i;?>].addColumn('number','Latency');
          data2[<?php print $i;?>].addRows(input_data[<?php print $i;?>]);
          chart2<?php print $i;?> = new google.visualization.LineChart(document.getElementById('pingChart<?php print $i;?>'));
          chart2<?php print $i;?>.draw(data2[<?php print $i;?>], options2[<?php print $i;?>]);

	}, 5000);



// Draw
chart2[<?php print $i;?>] = new google.visualization.LineChart(document.getElementById('pingChart<?php print $i;?>'));
chart2[<?php print $i;?>].draw(data2[<?php print $i;?>], options2[<?php print $i;?>]);

}


<?php
  }
?>


<!-- ping Chart -->


<!-- Deactivated Chart -->

<?php
  for($i=0;$i<$limited2;$i++)
  {
?>

google.charts.load('current',{packages:['corechart']});
google.charts.setOnLoadCallback(drawChart3<?php print $i;?>);

function drawChart3<?php print $i;?>() {
// Set Data
chart3[<?php print $i;?>] = new google.visualization.LineChart(document.getElementById('pingChart2<?php print $i;?>'));

input_data2[<?php print $i;?>] = [['Datetime','Latency'],[0,0]];

data3[<?php print $i;?>] = google.visualization.arrayToDataTable(input_data2[<?php print $i;?>]);

// Set Options
options3[<?php print $i;?>] = {
  title: 'Ping to <?php print $destination2[$i];?>',
  width:900 , height: 300,
  hAxis: {title: 'Date time'},
  vAxis: {title: 'Latency'},
  legend: 'none'
};

        input_data2[<?php print $i;?>] = [];
        //input_data.push(temp_array);
        $.getJSON('https://www.pingnetbox.com/script/ping_user_json.php?domain=<?php print $destination2[$i];?>', function(dataresult2<?php print $i;?>) {
                $.each(dataresult2<?php print $i;?>, function (key<?php print $i;?>, value<?php print $i;?>) {
                     //console.log(value<?php print $i;?>.Datetime+" "+value<?php print $i;?>.Latency);
                     temp_array<?php print $i;?> = [value<?php print $i;?>.Datetime,parseFloat(value<?php print $i;?>.Latency)];
                     //console.log(temp_array<?php print $i;?>[0]+" "+temp_array<?php print $i;?>[1]);
                     input_data2[<?php print $i;?>].push(temp_array<?php print $i;?>);
                     //console.log(input_data2[0][0]);
                });
        });

	setInterval(function() {
          data3[<?php print $i;?>] = new google.visualization.DataTable();
          data3[<?php print $i;?>].addColumn('string','Date Time');
          data3[<?php print $i;?>].addColumn('number','Latency');
          data3[<?php print $i;?>].addRows(input_data2[<?php print $i;?>]);
          chart3<?php print $i;?> = new google.visualization.LineChart(document.getElementById('pingChart2<?php print $i;?>'));
          chart3<?php print $i;?>.draw(data3[<?php print $i;?>], options3[<?php print $i;?>]);

	}, 5000);


// Draw
chart3[<?php print $i;?>] = new google.visualization.LineChart(document.getElementById('pingChart2<?php print $i;?>'));
chart3[<?php print $i;?>].draw(data3[<?php print $i;?>], options3[<?php print $i;?>]);

}


<?php
  }
?>


<!-- Deactivated Chart -->












<!-- Add Ping -->

function addPing()
{
	var domain = document.getElementById('addPing').value;
	$.getJSON('https://www.pingnetbox.com/script/addPing_json.php?domain='+domain, function(dataresult) {
                $.each(dataresult, function (key, value) {
                     	//console.log(value.Result);
			if(value.Result == "0")
			{
				document.getElementById("pingMessage").innerHTML = "Error! Ping Fail "+domain+" <br>";
				document.getElementById("pingMessage").style.color = "Red";
			}
			else
			{
				document.getElementById("pingMessage").innerHTML = "Ping Success "+domain+" "+value.Result+"ms <br>Add to schedule ping? <button id=submit onclick=\"schedulePing()\">Add Schedule Ping</button>";
				document.getElementById("pingMessage").style.color = "Green";
			}	
                });
        });
	
	
}

<!-- Add Ping -->

<!--- Add Schedule Ping -->

function schedulePing()
{
	var domain = document.getElementById('addPing').value;
        $.getJSON('https://www.pingnetbox.com/script/addSchedulePing_json.php?domain='+domain, function(dataresult) {
                $.each(dataresult, function (key, value) {
                        //console.log(value.Result);
                        if(value.Result == "0")
                        {
                                document.getElementById("pingMessage").innerHTML = value.Message+" "+domain+" <br>";
                                document.getElementById("pingMessage").style.color = "Red";
                        }
                        else
                        {
                                document.getElementById("pingMessage").innerHTML = value.Message+" "+domain+" "+value.Result+"ms , Page reload in 5 seconds";
                                document.getElementById("pingMessage").style.color = "Green";
				setTimeout(function(){
                                   window.location.reload();
                                }, 5000);

                        }
                });
        });	
}


<!--- Add Schedule Ping -->


<!--- Re Activative Ping -->

function reactivatePing(deactivate_domain)
{

        $.getJSON('https://www.pingnetbox.com/script/reActivatePing_json.php?domain='+deactivate_domain, function(dataresult) {
                $.each(dataresult, function (key, value) {
                        //console.log(value.Result);
                        if(value.Result == "0")
                        {
                                document.getElementById("text_"+deactivate_domain).innerHTML = value.Message+" "+deactivate_domain+"";
                                document.getElementById("text_"+deactivate_domain).style.color = "Red";
                        }
                        else
                        {
                                document.getElementById("text_"+deactivate_domain).innerHTML = value.Message+" "+deactivate_domain+", Page reload in 5 seconds";
                                document.getElementById("text_"+deactivate_domain).style.color = "Green";
                       		setTimeout(function(){
				   window.location.reload();
				}, 5000); 
			}
                });
        });
	
}


<!-- Re Activative Ping -->



<!--- Deactivate Ping -->

function deactivatePing(deactivate_domain)
{
	$.getJSON('https://www.pingnetbox.com/script/deactivatePing_json.php?domain='+deactivate_domain, function(dataresult) {
                $.each(dataresult, function (key, value) {
                        //console.log(value.Result);
                        if(value.Result == "0")
                        {
                                document.getElementById("text_"+deactivate_domain).innerHTML = value.Message+" "+deactivate_domain+"";
                                document.getElementById("text_"+deactivate_domain).style.color = "Red";
                        }
                        else
                        {
                                document.getElementById("text_"+deactivate_domain).innerHTML = value.Message+" "+deactivate_domain+", Page reload in 5 seconds";
                                document.getElementById("text_"+deactivate_domain).style.color = "Green";
				setTimeout(function(){
                                   window.location.reload();
                                }, 5000);
                        }
                });
        });
	
}


<!--- Deactivate Ping -->


</script>


<body>


<div class="sticky">
    <ul class="menu">
	<li>
	<a href="./#Intro"><img src=./logo.png /></a>
	</li>
	<div id="topmenu">	
	<li>
      <a href="./#Intro">Intro</a>
	</li>
	<li >
      <a href="./#Usage">Usage</a>
	</li>
	<li >
      <a href="./#Report">Report</a>
	</li>
	<li >
      <a href="./#About">About</a>
	</li>
	<li >
<?php
	if($username == "")
	{
?>
      <a href="#Intro"><button class="button" id="button" onclick="location.href='./signin.php'">Sign In</button></a>
<?php
	}
	else
	{
?>
	<div class="dropdown">
		<button class="button" id="button" onclick="location.href='./logout.php'">Logout: <?php echo $username ?></button>
		<div class="dropdown-content">
		    <a href="./ping.php">PING</a>
		    <a href="./traceroute.php">TRACEROUTE</a>
		    <a href="./whois.php">WHOIS</a>
		</div>
	</div>
<?php
	}
?>

        </li>

<?php
	if($username == "")
	{
?>
	<li >
      <a href="#Intro"><button class="button1" id="button1" onclick="location.href='./signup.php'">Join Us?</button></a> 
	</li>
<?php
	}
?>
	</div>
	<li>
	<a href="javascript:void(0);" class="icon" onclick="menufunction()">
	</li>
	<li>
	<hr width=100%>
	</li>
   </ul>

   <ul class="menu2">
        <li>
        <a href="#Intro"><img src=./logo.png /></a>
        </li>
        <div id="topmenu2">
        <li>
      <a href="#Intro">Intro</a>
        </li>
        <li >
      <a href="#Usage">Usage</a>
        </li>
        <li >
      <a href="#Report">Report</a>
        </li>
        <li >
      <a href="#About">About</a>
        </li>

<?php
        if($username == "")
        {
?>
        <li>
              <a href="./signin.php">Sign In</button></a>
        </li>
<?php
        }
        else
        {
?>
         <li>
      <a href="./ping.php">PING</a>
        </li>

         <li>
      <a href="./traceroute.php">TRACEROUTE</a>
        </li>

         <li>
      <a href="./whois.php">WHOIS</a>
        </li>

         <li>
      <a href="./logout.php">Logout: <?php echo $username ?></a>
        </li>


<?php
        }
        if($username == "")
        {
?>
        <li >
      <a href="./signup.php">Join Us?</button></a>
        </li>
<?php
        }
?>



        </div>
        <li>
        <a href="javascript:void(0);" class="icon" onclick="menufunction2()">
        </li>
        <li>
        <hr width=100%>
        </li>
   </ul>






</div>


<a class="anchor" id="Report"></a>
<div class="intext3">
        <h1>PING</h1>
	<h2>Please input domain name</h2>
        <input type=text id="addPing" size=50 /> <button id=submit onclick="addPing()">Ping</button>
	<br><br>
	<span id="pingMessage">
        </span>

	<br>
	<h2>Scheduled live Ping test <?php print $limited."/10"?>

	<?php

	for($i=0;$i<$limited;$i++)
	{

	?>

	<table>
	<tr><td>	
	<div id="pingChart<?php print $i ?>"></div>
	</td></tr>
	</table>	
	<br>
	<h3>Deactivate? <span id=text_<?php print $destination[$i];?>> </span></h3> <button id=deactivate_<?php print $destination[$i];?> onclick="deactivatePing('<?php print $destination[$i];?>')">Deactivate this ping</button>
	<hr>

	<?php
		
	}

	?>


	<br>
        <h2>Deactivated Ping test. Remain <?php print 10-$limited?> schedule test count available.

        <?php

        for($i=0;$i<$limited2;$i++)
        {

        ?>

        <table>
        <tr><td>
        <div id="pingChart2<?php print $i ?>"></div>
        </td></tr>
        </table>
        <br>
        <h3>Re-Activate it? <span id=text_<?php print $destination2[$i];?>> </span></h3> <button id=reactivate_<?php print $destination2[$i];?> onclick="reactivatePing('<?php print $destination2[$i];?>')">Re-activate this ping</button>
        <hr>

        <?php

        }

        ?>






</div>


<div class="footer">
	<br>	
	Copyright © 2022 PINGNETBOX.  All Right Reserved.
	<br>
</div>


</body>
</html>
	
